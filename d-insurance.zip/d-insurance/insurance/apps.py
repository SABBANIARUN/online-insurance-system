from django.apps import AppConfig


class InsuranceConfig(AppConfig):
    name = 'insurance'
